#include "entity.h"

bool operator<(Type t1, Type t2)
{
    return ((int) t1) < ((int) t2);
}

