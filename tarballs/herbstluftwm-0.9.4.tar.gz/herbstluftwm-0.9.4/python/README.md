# Python bindings for herbstluftwm

This wraps the `herbstclient` in order to provide a herbstluftwm library for python
with a native look and feel.
